<footer>
    <p>&copy; <?php echo date("Y"); ?> My Awesome Website. All rights reserved.</p>
    <!-- Copyright: It's over 9000! -->
</footer>